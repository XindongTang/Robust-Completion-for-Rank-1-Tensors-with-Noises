function v = sedumi_version ()
   v = '1.3.7';
end
