function y = type(x)
% @MOMCON/TYPE - Internal use only

y = x(1).type;

