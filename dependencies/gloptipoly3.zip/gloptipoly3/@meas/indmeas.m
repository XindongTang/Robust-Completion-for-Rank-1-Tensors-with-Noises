function m = INDMEAS(x)
% @MEAS/INDMEAS - Internal use only

% INDMEAS(X) returns the label of a scalar measure

% D. Henrion, 21 December 2006

m = x(1).meas;
