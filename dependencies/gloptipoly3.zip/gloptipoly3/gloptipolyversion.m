function v = gloptipolyversion
% GLOPTIPOLYVERSION - Current version of GloptiPoly

% Used in @MSDP/MSDP and @MSDP/MSOL
v = '3.10 of 5 July 2021';
