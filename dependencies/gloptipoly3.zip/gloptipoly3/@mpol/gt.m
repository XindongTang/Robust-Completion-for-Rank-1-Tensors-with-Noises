function z = gt(a,b)
% @MPOL/GT - Greater than

% D. Henrion, December 4, 2003
  
error('Please use non-strict inequalities');

