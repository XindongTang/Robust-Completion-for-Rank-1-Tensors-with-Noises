function s = split(x)
% @MOM/SPLIT - Internal use only
  
s = x(1).split;
