function m = indmeas(x)
% @MOM/INDMEAS - Internal use only

m = x(1).meas;
  
