function d = deg(x)
% @MOM/DEG - Internal use only

d = deg(x(1).split);
