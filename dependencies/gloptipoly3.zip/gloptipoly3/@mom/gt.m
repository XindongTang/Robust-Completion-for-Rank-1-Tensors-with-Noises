function z = gt(a,b)
% @MOM/GT - Greater than

% D. Henrion, December 4, 2003
  
error('Please use non-strict inequalities');

