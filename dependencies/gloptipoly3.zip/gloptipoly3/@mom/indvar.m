function m = indvar(x)
% @MOM/INDVAR - Internal use only

m = indvar(x(1).split);

  
