function z = lt(a,b)
% @MOM/LT - Less than

% D. Henrion, December 4, 2003
  
error('Please use non-strict inequalities');

