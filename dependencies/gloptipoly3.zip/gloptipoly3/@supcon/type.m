function y = type(x)
% @SUPCON/TYPE - Internal use only

y = x(1).type;

